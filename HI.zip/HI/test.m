close all; % closes all figures

% read images and convert to single format
HighFiImage = im2single(imread('./cat1.jpg'));
HighFiImage = rgb2gray(HighFiImage); % convert to grayscale

figure(1), hold off, imagesc(log(abs(fftshift(fft2(HighFiImage))))), axis image, title('cat fft2')


hs = 20;
fftsize = 1024;
Gaussian = fspecial('gaussian', hs*2+1, 2);
FftHighFiImage = fft2(HighFiImage, fftsize, fftsize);
FftGaussian = fft2(Gaussian, fftsize, fftsize);
HighFiImageFiltered = ifft2(FftHighFiImage .* FftGaussian);
HighFiImageFiltered =  HighFiImageFiltered(1+hs:size(HighFiImage,1)+hs, 1+hs:size(HighFiImage,2)+hs);
figure(2), hold off, colormap(gray), imagesc(real(HighFiImageFiltered)),  axis off, axis image, title('High Intensity');
LowFilteredImage = HighFiImage - HighFiImageFiltered;
figure(3), hold off, colormap(gray), imagesc(real(LowFilteredImage)),  axis off, axis image, title('Low Intensity');
figure(4), hold off, imagesc(real(HighFiImage)),  axis off, axis image, title('add Intensity');
% imwrite(HybridImage, './cat-fft2.jpg');

% im1_lowpass = imgaussfilt(HighFiImage, 8);
% figure(5), hold off, imagesc(log(abs(fftshift(fft2(im1_lowpass))))), axis image
% im2_highpass = HighFiImage - imgaussfilt(HighFiImage, 8);
% figure(6), hold off, imagesc(log(abs(fftshift(fft2(im2_highpass))))), axis image



