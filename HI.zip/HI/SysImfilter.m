function [imghybrid] = SysImfilter(im1, im2, cutoff_low, cutoff_high)

%��im1Ӧ�õ�ͨ�˲�
im1_lowpass = imgaussfilt(im1, cutoff_low);
figure('Name','iff2 Fourier Transform Im1_lowpass'), hold off, colormap(gray), imagesc(im1_lowpass), axis image
%figure('Name','Fourier Transform Im1_lowpass'), hold off, imagesc(log(abs(fftshift(fft2(im1_lowpass))))), axis image

%��im2Ӧ�ø�ͨ�˲�
im2_highpass = im2 - imgaussfilt(im2, cutoff_high);
figure('Name','iff2 Fourier Transform Im2_highpass'), colormap(gray), hold off, imagesc(im2_highpass), axis image
%figure('Name','Fourier Transform Im2_highpass'), hold off, imagesc(log(abs(fftshift(fft2(im2_highpass))))), axis image

%ͼ����
imghybrid = im1_lowpass + im2_highpass;
%figure('Name','Fourier Transform Hybrid'), hold off, imagesc(log(abs(fftshift(fft2(imghybrid))))), axis image

end
